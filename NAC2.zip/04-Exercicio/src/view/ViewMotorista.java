package view;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.dao.MotoristaDAO;
import br.com.fiap.dao.impl.MotoristaDAOImpl;
import br.com.fiap.entity.Motorista;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class ViewMotorista {
	public static void main(String[] args) {
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		MotoristaDAO dao=new MotoristaDAOImpl(em);
		
		List<Motorista>lista=dao.listar();
		
		System.out.println("Lista por parte do nome");
		
		lista=dao.buscarPorParteDoNome("a");
		for(Motorista item : lista) {
			System.out.println(item.getNome());
		}
		
	}

}
