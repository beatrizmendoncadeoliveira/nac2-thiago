package view;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import br.com.fiap.dao.CorridaDAO;
import br.com.fiap.dao.impl.CorridaDAOImpl;
import br.com.fiap.entity.Corrida;
import br.com.fiap.singleton.EntityManagerFactorySingleton;

public class ViewCorrida {

	public static void main(String[] args) {
		EntityManagerFactory fabrica = EntityManagerFactorySingleton.getInstance();
		EntityManager em = fabrica.createEntityManager();
		
		CorridaDAO dao=new CorridaDAOImpl(em);
		
		//Pesquisar corrida por data 
				Calendar inicio = new GregorianCalendar(2017, Calendar.AUGUST, 1);
				Calendar fim = new GregorianCalendar(2017, Calendar.DECEMBER, 31);
				List<Corrida>corrida=dao.buscarCorridaPorIntervaloDeTempo(inicio, fim);
				
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				
			
				corrida.forEach(c -> System.out.println(sdf.format(c.getData().getTime())));

	}

}
