package br.com.fiap.entity;

public enum Genero {

	MASCULINO, FEMININO, OUTROS;
	
}
