package br.com.fiap.dao;

import java.util.List;

import br.com.fiap.entity.Motorista;

public interface MotoristaDAO extends GenericDAO<Motorista, Long>{

	public List<Motorista>buscarPorParteDoNome(String nome);
	
}



