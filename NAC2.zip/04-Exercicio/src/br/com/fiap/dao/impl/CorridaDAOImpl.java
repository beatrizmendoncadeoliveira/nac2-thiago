package br.com.fiap.dao.impl;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import br.com.fiap.dao.CorridaDAO;
import br.com.fiap.entity.Corrida;

public class CorridaDAOImpl extends GenericDAOImpl<Corrida, Integer> implements CorridaDAO{

	public CorridaDAOImpl(EntityManager em) {
		super(em);
	}

	@Override
	public List<Corrida> buscarCorridaPorIntervaloDeTempo(Calendar inicio, Calendar fim) {
		TypedQuery<Corrida>query=em.createQuery("from Corrida c  where c.data between :i and :f",
																					Corrida.class);
		query.setParameter("i", inicio);
		query.setParameter("f", fim);
		query.setMaxResults(30);
		return query.getResultList();
	}

}
