package br.com.fiap.dao;

import br.com.fiap.entity.Pagamento;

public interface PagamentoDAO extends GenericDAO<Pagamento, Integer>{

	
}
